setwd("D:/대학원/퓨레임/nash프로젝트")

##패키지 불러오기
library(ChemmineR)
library(ChemmineOB)
library(rcdk)
library(Rcpi)
library(randomForest)
library(ggplot2)
require(gridExtra)
library(data.table)


#데이터 불러오기 
library(data.table)
nash <- fread("inhibit_nash_vaild.csv",header=F)
nash1 <- as.data.frame(nash)
nash1 <- apply(nash1,1,function(x){gsub("!","",x)})
nash1



##물성 계산 함수들 


##### Sub-Functions

# QED Sub-Functions
ads=function(x,params){
  a=params$A
  b=params$B
  c=params$C
  d=params$D
  e=params$E
  f=params$F
  dx_max=params$DMAX
  return((a+(b/(1+exp(-1*(x-c+d/2)/e))*(1-1/(1+exp(-1*(x-c-d/2)/f)))))/dx_max)
}

ads_params=function(var){
  if(var=="MW"){
    return(list(A=2.817065973,B=392.5754953,C=290.7489764,D=2.419764353,E=49.22325677,F=65.37051707,DMAX=104.98055614))
  }
  if(var=="ALOGP"){
    return(list(A=3.172690585,B=137.8624751,C=2.534937431,D=4.581497897,E=0.822739154,F=0.576295591,DMAX=131.31866035))
  }
  if(var=="HBA"){
    return(list(A=2.948620388,B=160.4605972,C=3.615294657,D=4.435986202,E=0.290141953,F=1.300669958,DMAX=148.77630464))
  }
  if(var=="HBD"){
    return(list(A=1.618662227,B=1010.051101,C=0.985094388,D=0.000000000001,E=0.713820843,F=0.920922555,DMAX=258.16326158))
  }
  if(var=="PSA"){
    return(list(A=1.876861559,B=125.2232657,C=62.90773554,D=87.83366614,E=12.01999824,F=28.51324732,DMAX=104.56861672))
  }
  if(var=="ROTB"){
    return(list(A=0.01,B=272.4121427,C=2.558379970,D=1.565547684,E=1.271567166,F=2.758063707,DMAX=105.44204028))
  }
  if(var=="AROM"){
    return(list(A=3.217788970,B=957.7374108,C=2.274627939,D=0.000000000001,E=1.317690384,F=0.375760881,DMAX=312.33726097))
  }
  if(var=="ALERTS"){
    return(list(A=0.01,B=1199.094025,C=-0.09002883,D=0.000000000001,E=0.185904477,F=0.875193782,DMAX=417.72531400))
  } 
  return(NA)
}

##QED
calculate_QED=function(drug){
  weights=c(MW=0.66,ALOGP=0.46,HBA=0.05,HBD=0.61,PSA=0.06,ROTB=0.65,AROM=0.48,ALERTS=0.95)
  return(list(uQED=exp(sum(sapply(1:length(drug),function(i) log(ads(drug[i],ads_params(names(drug)[i])))))/length(weights)),wQED=exp(sum(weights * sapply(1:length(drug),function(i) log(ads(drug[i],ads_params(names(drug)[i])))))/sum(weights))))  
}

data=readRDS("PrOCTOR.rds")


##물성계산
getStructuralFeatures=function(SMILE){
  mol=smiles2sdf(as(as.vector(SMILE),"SMIset"))
  props=propOB(mol)
  
  MW=props$MW # molecular weight
  XlogP=props$logP # octanol-water partition coefficient log P
  HBD=props$HBD #hydrogen bond donor count
  HBA=props$HBA2 #hydrogen bond acceptor count
  PSA=props$TPSA #polar surface area
  FC=sum(bonds(mol, type="bonds")[[1]]$charge) #formal charge
  RBC=extractDrugRotatableBondsCount(parse.smiles(as.vector(SMILE)))[[1]] #rotatable bonds count
  refr=props$MR # refractivity
  alogP=NA #
  nA=sum(atomcountMA(mol,addH=FALSE)) #number atoms
  AROMs=as.vector(rings(mol, type="count", arom=TRUE)[2])
  nALERTS=sum(sapply(data$unwantedALERTS,function(x) as.numeric(smartsSearchOB(mol,x,uniqueMatches = TRUE)!=0)))
  
  Ro5=as.numeric(MW<500&HBD<5&HBA<10&XlogP<5)
  Veber=as.numeric(RBC<=10&PSA<=140)
  Ghose=as.numeric(PSA<140&(findInterval(XlogP,c(-0.4,5.6))==1)&(findInterval(MW,c(160,480))==1)&(findInterval(nA,c(20,70))==1))
  QED=calculate_QED(c(MW=MW,ALOGP=XlogP,HBA=HBA,HBD=HBD,PSA=PSA,ROTB=RBC,AROM=AROMs,ALERTS=nALERTS)) 
  
  return(data.frame(MolecularWeight=MW,XLogP=XlogP,HydrogenBondDonorCount=HBD,HydrogenBondAcceptorCount=HBA,PolarSurfaceArea=PSA,FormalCharge=FC,NumRings=AROMs,RotatableBondCount=RBC,Refractivity=refr,Ro5=Ro5,Ghose=Ghose,Veber=Veber,wQED=QED$wQED))
}






##물성계산 파일 저장 

export_data <- function(data) {
  data=as.vector(data)
  name <- c("MolecularWeight","XLogP","HydrogenBondDonorCount","HydrogenBondAcceptorCount",
            "PolarSurfaceArea","FormalCharge","NumRings","RotatableBondCount",
            "Refractivity","Ro5", "Ghose","Veber","wQED")
  m <- matrix(ncol=13,dimnames=list(NULL,name))
  k=NULL
  for(i in 1:length(data)){
    cat(i)
    assign("k",getStructuralFeatures(data[i]))
    m <- rbind(m,k)
  }
  m <- m[-1,]
  rownames(m) <- NULL
  m <- cbind(smiles=data,m)
  molfeature<<-as.data.frame(m)
  return(write.csv(molfeature,"molfeat.csv",row.names=F))
}

export_data(nash1)




